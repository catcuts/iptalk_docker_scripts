#!/usr/bin/bash

echo "For now please install docker manually."
