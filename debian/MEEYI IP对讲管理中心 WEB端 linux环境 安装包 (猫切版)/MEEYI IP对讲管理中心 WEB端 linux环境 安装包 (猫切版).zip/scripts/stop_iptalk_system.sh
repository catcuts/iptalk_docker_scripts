#!/usr/bin/bash

bash stop_iptalk.sh && bash stop_iptalk_mysql.sh